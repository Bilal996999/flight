import React from 'react'

const Flight = () => {
  return (
    <div>Flight</div>
  )
}

export default Flight