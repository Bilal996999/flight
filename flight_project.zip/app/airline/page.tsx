import React from 'react'

const Airline = () => {
  return (
    <div className='min-height-screen'>
        Airline Page
    </div>
  )
}

export default Airline