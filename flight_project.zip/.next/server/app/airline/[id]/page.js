(() => {
var exports = {};
exports.id = 415;
exports.ids = [415];
exports.modules = {

/***/ 8038:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react");

/***/ }),

/***/ 8704:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-dom/server-rendering-stub");

/***/ }),

/***/ 7897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-server-dom-webpack/client");

/***/ }),

/***/ 6786:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react/jsx-runtime");

/***/ }),

/***/ 5868:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/app-render");

/***/ }),

/***/ 1844:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/get-segment-param");

/***/ }),

/***/ 6624:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/future/helpers/interception-routes");

/***/ }),

/***/ 5281:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/future/route-modules/route-module");

/***/ }),

/***/ 7085:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context");

/***/ }),

/***/ 1830:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/get-img-props");

/***/ }),

/***/ 199:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hash");

/***/ }),

/***/ 6864:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head");

/***/ }),

/***/ 9569:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hooks-client-context");

/***/ }),

/***/ 2210:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config");

/***/ }),

/***/ 5359:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config-context");

/***/ }),

/***/ 7160:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context");

/***/ }),

/***/ 893:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix");

/***/ }),

/***/ 2336:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url");

/***/ }),

/***/ 7887:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/handle-smooth-scroll");

/***/ }),

/***/ 8735:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-bot");

/***/ }),

/***/ 120:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-local-url");

/***/ }),

/***/ 8231:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path");

/***/ }),

/***/ 4614:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/path-has-prefix");

/***/ }),

/***/ 3750:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash");

/***/ }),

/***/ 982:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-href");

/***/ }),

/***/ 9618:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/server-inserted-html");

/***/ }),

/***/ 8423:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils");

/***/ }),

/***/ 8658:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils/warn-once");

/***/ }),

/***/ 9491:
/***/ ((module) => {

"use strict";
module.exports = require("assert");

/***/ }),

/***/ 2361:
/***/ ((module) => {

"use strict";
module.exports = require("events");

/***/ }),

/***/ 7147:
/***/ ((module) => {

"use strict";
module.exports = require("fs");

/***/ }),

/***/ 3685:
/***/ ((module) => {

"use strict";
module.exports = require("http");

/***/ }),

/***/ 5687:
/***/ ((module) => {

"use strict";
module.exports = require("https");

/***/ }),

/***/ 2037:
/***/ ((module) => {

"use strict";
module.exports = require("os");

/***/ }),

/***/ 1017:
/***/ ((module) => {

"use strict";
module.exports = require("path");

/***/ }),

/***/ 2781:
/***/ ((module) => {

"use strict";
module.exports = require("stream");

/***/ }),

/***/ 6224:
/***/ ((module) => {

"use strict";
module.exports = require("tty");

/***/ }),

/***/ 7310:
/***/ ((module) => {

"use strict";
module.exports = require("url");

/***/ }),

/***/ 3837:
/***/ ((module) => {

"use strict";
module.exports = require("util");

/***/ }),

/***/ 9796:
/***/ ((module) => {

"use strict";
module.exports = require("zlib");

/***/ }),

/***/ 6905:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   GlobalError: () => (/* reexport default from dynamic */ next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_2___default.a),
/* harmony export */   __next_app__: () => (/* binding */ __next_app__),
/* harmony export */   originalPathname: () => (/* binding */ originalPathname),
/* harmony export */   pages: () => (/* binding */ pages),
/* harmony export */   routeModule: () => (/* binding */ routeModule),
/* harmony export */   tree: () => (/* binding */ tree)
/* harmony export */ });
/* harmony import */ var next_dist_server_future_route_modules_app_page_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7262);
/* harmony import */ var next_dist_server_future_route_modules_app_page_module__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_future_route_modules_app_page_module__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_dist_server_future_route_kind__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9513);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1823);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2502);
/* harmony import */ var next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_3__);
/* harmony reexport (unknown) */ var __WEBPACK_REEXPORT_OBJECT__ = {};
/* harmony reexport (unknown) */ for(const __WEBPACK_IMPORT_KEY__ in next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_3__) if(["default","tree","pages","GlobalError","originalPathname","__next_app__","routeModule"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) __WEBPACK_REEXPORT_OBJECT__[__WEBPACK_IMPORT_KEY__] = () => next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_3__[__WEBPACK_IMPORT_KEY__]
/* harmony reexport (unknown) */ __webpack_require__.d(__webpack_exports__, __WEBPACK_REEXPORT_OBJECT__);
// @ts-ignore this need to be imported from next/dist to be external


const AppPageRouteModule = next_dist_server_future_route_modules_app_page_module__WEBPACK_IMPORTED_MODULE_0__.AppPageRouteModule;
// We inject the tree and pages here so that we can use them in the route
// module.
const tree = {
        children: [
        '',
        {
        children: [
        'airline',
        {
        children: [
        '[id]',
        {
        children: ['__PAGE__', {}, {
          page: [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 6277)), "D:\\flight_project\\app\\airline\\[id]\\page.jsx"],
          
        }]
      },
        {
        
        
      }
      ]
      },
        {
        
        metadata: {
    icon: [(async (props) => (await Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 7481))).default(props))],
    apple: [],
    openGraph: [],
    twitter: [],
    manifest: undefined
  }
      }
      ]
      },
        {
        'layout': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 1284)), "D:\\flight_project\\app\\layout.tsx"],
'not-found': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 5493, 23)), "next/dist/client/components/not-found-error"],
        metadata: {
    icon: [(async (props) => (await Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 7481))).default(props))],
    apple: [],
    openGraph: [],
    twitter: [],
    manifest: undefined
  }
      }
      ]
      }.children;
const pages = ["D:\\flight_project\\app\\airline\\[id]\\page.jsx"];

// @ts-expect-error - replaced by webpack/turbopack loader

const __next_app_require__ = __webpack_require__
const __next_app_load_chunk__ = () => Promise.resolve()
const originalPathname = "/airline/[id]/page";
const __next_app__ = {
    require: __next_app_require__,
    loadChunk: __next_app_load_chunk__
};

// Create and export the route module that will be consumed.
const routeModule = new AppPageRouteModule({
    definition: {
        kind: next_dist_server_future_route_kind__WEBPACK_IMPORTED_MODULE_1__.RouteKind.APP_PAGE,
        page: "/airline/[id]/page",
        pathname: "/airline/[id]",
        // The following aren't used in production.
        bundlePath: "",
        filename: "",
        appPaths: []
    },
    userland: {
        loaderTree: tree
    }
});

//# sourceMappingURL=app-page.js.map

/***/ }),

/***/ 1706:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 954, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 5978));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 4571))

/***/ }),

/***/ 6277:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ page)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(6786);
// EXTERNAL MODULE: ./components/AirlineTable.jsx
var AirlineTable = __webpack_require__(3403);
// EXTERNAL MODULE: ./components/AboutUs.jsx + 1 modules
var AboutUs = __webpack_require__(959);
// EXTERNAL MODULE: ./node_modules/next/dist/build/webpack/loaders/next-flight-loader/module-proxy.js
var module_proxy = __webpack_require__(1363);
;// CONCATENATED MODULE: ./components/HeroFrom.jsx

const proxy = (0,module_proxy.createProxy)(String.raw`D:\flight_project\components\HeroFrom.jsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule, $$typeof } = proxy;
const __default__ = proxy.default;


/* harmony default export */ const HeroFrom = (__default__);
// EXTERNAL MODULE: ./node_modules/axios/lib/axios.js + 46 modules
var axios = __webpack_require__(3078);
;// CONCATENATED MODULE: ./fetch/AirlineFlight.jsx


async function AirlineFlight(slug) {
    const airlinesFlights = await axios/* default */.Z.get(`https://rdpmarketplace.com/backend/airline-flight/${slug}`);
    //console.log(airlines.data)
    return airlinesFlights.data.data;
}

;// CONCATENATED MODULE: ./constants/flight-data.js
const flight_data = [
    {
        No: "UA9118",
        Departure: "10:05",
        Arrival: "13:05",
        Origin: "(FRA) Frankfurt, Germany",
        Destination: "(VNO) Vilnius, Lithuania",
        Terminal: "Dep: 1 - Arr: A",
        Status: "Scheduled"
    },
    {
        No: "UA9192",
        Departure: "09:55",
        Arrival: "13:05",
        Origin: "(FRA) Frankfurt, Germany",
        Destination: "(RIX) Riga, Latvia",
        Terminal: "Dep: 1",
        Status: "Scheduled"
    },
    {
        No: "UA9141",
        Departure: "06:40",
        Arrival: "08:45",
        Origin: "(NAP) Naples, Italy",
        Destination: "(FRA) Frankfurt, Germany",
        Terminal: "- Arr: 1",
        Status: "Scheduled"
    }
];
/* harmony default export */ const constants_flight_data = ((/* unused pure expression or super */ null && (flight_data)));

// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(5124);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
;// CONCATENATED MODULE: ./app/airline/[id]/page.jsx







const AirlineID = async ({ params })=>{
    const airlineFlights = await AirlineFlight(params.id);
    console.log(airlineFlights);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "flex min-h-screen flex-col items-center justify-between ",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("section", {
                className: "w-100 p-[80px] bg-[url(https://cdn.flight-status.info/images/banner.webp)]",
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "container",
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("h1", {
                            className: "text-white text-[32px]",
                            children: [
                                airlineFlights[0]?.airline?.name,
                                " Flight Status"
                            ]
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                            className: "text-black text-[14px] mt-6",
                            children: "United Airlines is a major American airline headquartered at Willis Tower in Chicago, Illinois. United gives you the opportunity to choose from 4,500 daily flights to more than 300 cities across five continents. They serves an extensive network in the U.S., with more than 200 domestic destinations. We provide the best method to check United Airlines Flight Status today at here by input flight number or departure and arrivals airport to get real time flight status tracking including info about arrivals, delays, cancellations . You also check the united status by toll free phone number +1 800 864 8331"
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "bg-white w-100 shadow-sm px-5 py-10 mt-4",
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "flex space-x-5 items-center",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                            className: "text-[14px] mb-0",
                                            children: "Check Status:"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                            className: "block cursor-pointer text-[14px] rounded-full bg-[#0078D2] p-2 text-white",
                                            children: "Airlines and airports status"
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx(HeroFrom, {})
                            ]
                        })
                    ]
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "container pt-20",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                        className: "text-left w-100 mb-10 text-[#0078d2] text-[24px]",
                        children: "List Airlines for checking Flight Status"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "relative overflow-x-auto w-100 mx-auto",
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("table", {
                            className: "w-full text-sm text-left text-gray-500 dark:text-gray-400 mb-[40px]",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("thead", {
                                    className: "text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400",
                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("tr", {
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("th", {
                                                scope: "col",
                                                className: "px-6 py-3",
                                                children: "No."
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("th", {
                                                scope: "col",
                                                className: "px-6 py-3",
                                                children: "Departure"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("th", {
                                                scope: "col",
                                                className: "px-6 py-3",
                                                children: "Arrival"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("th", {
                                                scope: "col",
                                                className: "px-6 py-3",
                                                children: "Origin"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("th", {
                                                scope: "col",
                                                className: "px-6 py-3 ps-14",
                                                children: "Destination"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("th", {
                                                scope: "col",
                                                className: "px-6 py-3",
                                                children: "Terminal"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("th", {
                                                scope: "col",
                                                className: "px-6 py-3",
                                                children: "Live Status"
                                            })
                                        ]
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("tbody", {
                                    children: airlineFlights?.slice(0, 20).map((i)=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)("tr", {
                                            className: "bg-white border-b dark:bg-gray-800 dark:border-gray-700",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("td", {
                                                    className: "px-6 py-4 font-bold text-[#0078d2]",
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                        className: "no-underline",
                                                        href: `/flight/${i.flight.iata}`,
                                                        children: i.flight.iata
                                                    })
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("td", {
                                                    className: "px-6 py-4 font-bold text-gray-800",
                                                    children: i.departure.scheduled.slice(11, 16)
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("td", {
                                                    className: "px-6 py-4 font-bold text-gray-800",
                                                    children: i.arrival.scheduled.slice(11, 16)
                                                }),
                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("td", {
                                                    className: "px-6 py-4 font-regular text-gray-800",
                                                    children: [
                                                        "(",
                                                        i.departure.iata,
                                                        ") ",
                                                        i.departure.airport,
                                                        " "
                                                    ]
                                                }),
                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("td", {
                                                    className: "px-6 py-4 font-regular text-gray-800 ps-14",
                                                    children: [
                                                        "(",
                                                        i.arrival.iata,
                                                        ") ",
                                                        i.arrival.airport
                                                    ]
                                                }),
                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("td", {
                                                    className: "px-6 py-4 font-regular text-gray-800 w-[250px]",
                                                    children: [
                                                        "Dep ",
                                                        i.departure.terminal || "none",
                                                        " - Arr ",
                                                        i.arrival.terminal || "none"
                                                    ]
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("td", {
                                                    className: "px-6 py-4 font-regular text-white bg-[#006100] w-[200px] capitalize",
                                                    children: i.flight_status
                                                })
                                            ]
                                        }, i.No))
                                })
                            ]
                        })
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "container py-10",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                        className: "text-[#0078d2] text-[28px] mb-6",
                        children: "United Airlines"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                        className: "text-black text-[12px]",
                        children: "The third-largest airline in the world is one of the major American Airlines to date. United Airlines, Inc. which is commonly called just United, is headquartered in Willis Tower in Chicago, Illinois, and has eight hubs around the world. United operates largely on domestic and international route networks in major cities and small towns across the United States and to all six continents."
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "container mb-10",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                        className: "text-[#0078d2] text-[28px] mb-6",
                        children: "United Airlines Destination Domestic, International"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                        className: "text-black text-[12px]",
                        children: "United Airlines headquarters for the air carrier's parent company, United Continental Holdings, are in Chicago, serving North America, Asia, Latin America, the Caribbean, and Europe. United operates flights to 238 domestic destinations and 118 international destinations in 48 countries or regions across five continents. In spring 2021, United will once again fly regularly to all 6 inhabited continents following the reinstatement of scheduled year-round flights to Africa"
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "container mb-10",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                        className: "text-[#0078d2] text-[28px] mb-6",
                        children: "Cancelation & Refund Policy"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                        className: "text-black text-[12px]",
                        children: "United Airlines value and understands circumstances causes travel plans cancelation unexpectedly. United's 24-hour flexible booking policy gives you the freedom to make changes to select reservations within 24 hours of booking and ticketing, without being charged change fees if you made your purchase one week or more before the flight was scheduled to depart. This includes canceling your reservation and requesting a full refund of the ticket price."
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                        className: "text-black text-[12px]",
                        children: "Although Basic Economy reservations aren't eligible for changes within 24 hours, they're still eligible for a full refund if you cancel within 24 hours and you made your purchase one week or more before the flight was scheduled to depart"
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const page = (AirlineID);


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [587,971,858,317,857,959], () => (__webpack_exec__(6905)));
module.exports = __webpack_exports__;

})();