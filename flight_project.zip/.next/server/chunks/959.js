"use strict";
exports.id = 959;
exports.ids = [959];
exports.modules = {

/***/ 959:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  Z: () => (/* binding */ components_AboutUs)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(6786);
// EXTERNAL MODULE: ./node_modules/next/dist/compiled/react/react.shared-subset.js
var react_shared_subset = __webpack_require__(2947);
// EXTERNAL MODULE: ./node_modules/axios/lib/axios.js + 46 modules
var axios = __webpack_require__(3078);
;// CONCATENATED MODULE: ./fetch/AboutusFetch.jsx

async function AboutusFetch() {
    const aboutus = await axios/* default */.Z.get("https://rdpmarketplace.com/backend/about-us");
    //console.log(airlines.data)
    return aboutus.data;
}

;// CONCATENATED MODULE: ./components/AboutUs.jsx



const AboutUs = async ()=>{
    const aboutusData = await AboutusFetch();
    console.log(aboutusData);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "container py-[100px]",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                className: "text-[#0078d2] text-[28px] mb-6",
                dangerouslySetInnerHTML: {
                    __html: aboutusData.data.title
                }
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "text-black text-[12px]",
                dangerouslySetInnerHTML: {
                    __html: aboutusData.data.description
                }
            })
        ]
    });
};
/* harmony default export */ const components_AboutUs = (AboutUs);


/***/ })

};
;