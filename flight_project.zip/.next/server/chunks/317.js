exports.id = 317;
exports.ids = [317];
exports.modules = {

/***/ 7363:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 8258))

/***/ }),

/***/ 8502:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 1232, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 2987, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 831, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 6926, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 4282, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 6505, 23))

/***/ }),

/***/ 8258:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1440);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_1__);
/* __next_internal_client_entry_do_not_use__ default auto */ 

const NavbarComponent = ()=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("header", {
        className: "bi-header border-b-[1px]",
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "container flex flex-wrap items-center justify-between h-[80px] space-x-10",
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "flex-col self-center justify-center text-white",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                        className: "font-bold text-[18px]",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
                            href: "/",
                            className: "no-underline text-white",
                            children: "LOGO HERE"
                        })
                    })
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "flex-col self-center justify-center text-black",
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("ul", {
                        className: "flex space-x-10 mb-0",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                className: "font-bold text-[14px]",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
                                    href: "/airline/united-airlines",
                                    className: "no-underline text-[#149CE2] mb-0",
                                    children: " UNITED STATUS"
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                className: "font-bold text-[14px]",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
                                    href: "/airline/american-airline",
                                    className: "no-underline text-[#149CE2] mb-0",
                                    children: " AMERICAN AIRLINES "
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                className: "font-bold text-[14px]",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
                                    href: "/airline/delta-air-lines",
                                    className: "no-underline text-[#149CE2] mb-0",
                                    children: "DELTA STATUS"
                                })
                            })
                        ]
                    })
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "flex-col self-center justify-center text-black",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("form", {
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "sm:col-span-4",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "mt-2",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "flex rounded-md shadow-sm ring-1 ring-inset ring-gray-300 focus-within:ring-2 focus-within:ring-inset focus-within:ring-indigo-600 sm:max-w-md",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                        type: "text",
                                        name: "username",
                                        id: "username",
                                        className: "block flex-1 border-0 bg-transparent ps-4 py-1.5 pl-1 text-gray-900 placeholder:text-gray-400 sm:text-sm sm:leading-6",
                                        placeholder: "Enter Keyword for search"
                                    })
                                })
                            })
                        })
                    })
                })
            ]
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (NavbarComponent);


/***/ }),

/***/ 1284:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ RootLayout),
  metadata: () => (/* binding */ metadata)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(6786);
// EXTERNAL MODULE: ./node_modules/next/font/google/target.css?{"path":"app\\layout.tsx","import":"Inter","arguments":[{"subsets":["latin"]}],"variableName":"inter"}
var target_path_app_layout_tsx_import_Inter_arguments_subsets_latin_variableName_inter_ = __webpack_require__(2411);
var target_path_app_layout_tsx_import_Inter_arguments_subsets_latin_variableName_inter_default = /*#__PURE__*/__webpack_require__.n(target_path_app_layout_tsx_import_Inter_arguments_subsets_latin_variableName_inter_);
// EXTERNAL MODULE: ./node_modules/next/dist/build/webpack/loaders/next-flight-loader/module-proxy.js
var module_proxy = __webpack_require__(1363);
;// CONCATENATED MODULE: ./components/Navbar.tsx

const proxy = (0,module_proxy.createProxy)(String.raw`D:\flight_project\components\Navbar.tsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule, $$typeof } = proxy;
const __default__ = proxy.default;


/* harmony default export */ const Navbar = (__default__);
// EXTERNAL MODULE: ./node_modules/next/dist/compiled/react/react.shared-subset.js
var react_shared_subset = __webpack_require__(2947);
;// CONCATENATED MODULE: ./components/Footer.jsx


const Footer = ()=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: "bg-[url(https://cdn.flight-status.info/images/footer-pattern.jpg)] bg-repeat py-[80px]",
        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
            className: "container",
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "flex justify-between items-start flex-wrap",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "max-xl:w-[25%] pr-[50px] max-lg:w-[50%] max-sm:w-[100%]",
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("h3", {
                                className: "text-[20px] font-bold text-white",
                                children: [
                                    "AMERICAN",
                                    /*#__PURE__*/ jsx_runtime_.jsx("hr", {})
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                className: "list-none ps-0",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                        className: "before:content-['\xbb'] before:text-[20px] before:mr-4 before:text-[#149CE2] before:font-bold text-white font-light",
                                        children: "Frontier Airlines"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                        className: "before:content-['\xbb'] before:text-[20px] before:mr-4 before:text-[#149CE2] before:font-bold text-white font-light",
                                        children: "Southwest Airlines"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                        className: "before:content-['\xbb'] before:text-[20px] before:mr-4 before:text-[#149CE2] before:font-bold text-white font-light",
                                        children: "easyJet"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                        className: "before:content-['\xbb'] before:text-[20px] before:mr-4 before:text-[#149CE2] before:font-bold text-white font-light",
                                        children: "Air Canada"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                        className: "before:content-['\xbb'] before:text-[20px] before:mr-4 before:text-[#149CE2] before:font-bold text-white font-light",
                                        children: "Alaska"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                        className: "before:content-['\xbb'] before:text-[20px] before:mr-4 before:text-[#149CE2] before:font-bold text-white font-light",
                                        children: "Westjet"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                        className: "before:content-['\xbb'] before:text-[20px] before:mr-4 before:text-[#149CE2] before:font-bold text-white font-light",
                                        children: "FinnAir"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                        className: "before:content-['\xbb'] before:text-[20px] before:mr-4 before:text-[#149CE2] before:font-bold text-white font-light",
                                        children: "KLM Flight Status"
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "max-xl:w-[25%] pl-[25px] pr-[25px] max-lg:w-[50%] max-sm:w-[100%]",
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("h3", {
                                className: "text-[20px] font-bold text-white",
                                children: [
                                    "EUROPE",
                                    /*#__PURE__*/ jsx_runtime_.jsx("hr", {})
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                className: "list-none ps-0",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                        className: "before:content-['\xbb'] before:text-[20px] before:mr-4 before:text-[#149CE2] before:font-bold text-white font-light",
                                        children: "Air France"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                        className: "before:content-['\xbb'] before:text-[20px] before:mr-4 before:text-[#149CE2] before:font-bold text-white font-light",
                                        children: "Lufthansa"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                        className: "before:content-['\xbb'] before:text-[20px] before:mr-4 before:text-[#149CE2] before:font-bold text-white font-light",
                                        children: "Turkish Airlines"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                        className: "before:content-['\xbb'] before:text-[20px] before:mr-4 before:text-[#149CE2] before:font-bold text-white font-light",
                                        children: "British Airways"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                        className: "before:content-['\xbb'] before:text-[20px] before:mr-4 before:text-[#149CE2] before:font-bold text-white font-light",
                                        children: "Go First"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                        className: "before:content-['\xbb'] before:text-[20px] before:mr-4 before:text-[#149CE2] before:font-bold text-white font-light",
                                        children: "Air India"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                        className: "before:content-['\xbb'] before:text-[20px] before:mr-4 before:text-[#149CE2] before:font-bold text-white font-light",
                                        children: "Etihad Airways"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                        className: "before:content-['\xbb'] before:text-[20px] before:mr-4 before:text-[#149CE2] before:font-bold text-white font-light",
                                        children: "Allegiant Air"
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "max-xl:w-[25%] pl-[25px] pr-[25px] max-lg:w-[50%] max-sm:w-[100%]",
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("h3", {
                                className: "text-[20px] font-bold text-white",
                                children: [
                                    "ASIA",
                                    /*#__PURE__*/ jsx_runtime_.jsx("hr", {})
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                className: "list-none ps-0",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                        className: "before:content-['\xbb'] before:text-[20px] before:mr-4 before:text-[#149CE2] before:font-bold text-white font-light",
                                        children: "Vietnam Airlines"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                        className: "before:content-['\xbb'] before:text-[20px] before:mr-4 before:text-[#149CE2] before:font-bold text-white font-light",
                                        children: "Singapore Airlines"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                        className: "before:content-['\xbb'] before:text-[20px] before:mr-4 before:text-[#149CE2] before:font-bold text-white font-light",
                                        children: "Thai Airways"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                        className: "before:content-['\xbb'] before:text-[20px] before:mr-4 before:text-[#149CE2] before:font-bold text-white font-light",
                                        children: "Japan Airlines"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                        className: "before:content-['\xbb'] before:text-[20px] before:mr-4 before:text-[#149CE2] before:font-bold text-white font-light",
                                        children: "China Southern"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                        className: "before:content-['\xbb'] before:text-[20px] before:mr-4 before:text-[#149CE2] before:font-bold text-white font-light",
                                        children: "Spirit Airlines"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                        className: "before:content-['\xbb'] before:text-[20px] before:mr-4 before:text-[#149CE2] before:font-bold text-white font-light",
                                        children: "All Nippon Airways"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                        className: "before:content-['\xbb'] before:text-[20px] before:mr-4 before:text-[#149CE2] before:font-bold text-white font-light",
                                        children: "Cebu Pacific"
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "max-xl:w-[25%] pl-[50px] max-lg:w-[50%] max-sm:w-[100%]",
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("h3", {
                                className: "text-[20px] font-bold text-white",
                                children: [
                                    "OTHERS AREA",
                                    /*#__PURE__*/ jsx_runtime_.jsx("hr", {})
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                className: "list-none ps-0",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                        className: "before:content-['\xbb'] before:text-[20px] before:mr-4 before:text-[#149CE2] before:font-bold text-white font-light",
                                        children: "Emirates"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                        className: "before:content-['\xbb'] before:text-[20px] before:mr-4 before:text-[#149CE2] before:font-bold text-white font-light",
                                        children: "Vueling"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                        className: "before:content-['\xbb'] before:text-[20px] before:mr-4 before:text-[#149CE2] before:font-bold text-white font-light",
                                        children: "Air New Zealand"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                        className: "before:content-['\xbb'] before:text-[20px] before:mr-4 before:text-[#149CE2] before:font-bold text-white font-light",
                                        children: "Saudia Airlines"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                        className: "before:content-['\xbb'] before:text-[20px] before:mr-4 before:text-[#149CE2] before:font-bold text-white font-light",
                                        children: "Iberia"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                        className: "before:content-['\xbb'] before:text-[20px] before:mr-4 before:text-[#149CE2] before:font-bold text-white font-light",
                                        children: "Qantas"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                        className: "before:content-['\xbb'] before:text-[20px] before:mr-4 before:text-[#149CE2] before:font-bold text-white font-light",
                                        children: "Korean Air"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                        className: "before:content-['\xbb'] before:text-[20px] before:mr-4 before:text-[#149CE2] before:font-bold text-white font-light",
                                        children: "Virgin Australia"
                                    })
                                ]
                            })
                        ]
                    })
                ]
            })
        })
    });
};
/* harmony default export */ const components_Footer = (Footer);

// EXTERNAL MODULE: ./app/globals.css
var globals = __webpack_require__(7272);
// EXTERNAL MODULE: ./node_modules/bootstrap/dist/css/bootstrap.css
var bootstrap = __webpack_require__(8399);
;// CONCATENATED MODULE: ./app/layout.tsx






const metadata = {
    title: "Check Flight Status",
    description: "Flight Status Tracker / Flight Tracking"
};
function RootLayout({ children }) {
    return /*#__PURE__*/ jsx_runtime_.jsx("html", {
        lang: "en",
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("body", {
            className: (target_path_app_layout_tsx_import_Inter_arguments_subsets_latin_variableName_inter_default()).className,
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx(Navbar, {}),
                children,
                /*#__PURE__*/ jsx_runtime_.jsx(components_Footer, {})
            ]
        })
    });
}


/***/ }),

/***/ 7481:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var next_dist_lib_metadata_get_metadata_route__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(85);
/* harmony import */ var next_dist_lib_metadata_get_metadata_route__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_lib_metadata_get_metadata_route__WEBPACK_IMPORTED_MODULE_0__);
  

  /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((props) => {
    const imageData = {"type":"image/x-icon","sizes":"16x16"}
    const imageUrl = (0,next_dist_lib_metadata_get_metadata_route__WEBPACK_IMPORTED_MODULE_0__.fillMetadataSegment)(".", props.params, "favicon.ico")

    return [{
      ...imageData,
      url: imageUrl + "",
    }]
  });

/***/ }),

/***/ 7272:
/***/ (() => {



/***/ })

};
;