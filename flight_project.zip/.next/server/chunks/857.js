"use strict";
exports.id = 857;
exports.ids = [857];
exports.modules = {

/***/ 5978:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ components_AirlineTable)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(6786);
// EXTERNAL MODULE: ./node_modules/axios/lib/axios.js + 46 modules
var lib_axios = __webpack_require__(3258);
;// CONCATENATED MODULE: ./fetch/AirlineFetch.jsx


async function AirlineFetch() {
    const airlines = await lib_axios/* default */.Z.get("https://rdpmarketplace.com/backend/airlines");
    //console.log(airlines.data)
    return airlines.data;
}

;// CONCATENATED MODULE: ./fetch/AirlineFlight.jsx


async function AirlineFlight(slug) {
    const airlinesFlights = await axios.get(`https://rdpmarketplace.com/backend/airline-flight/${slug}`);
    //console.log(airlines.data)
    return airlinesFlights.data.data;
}

// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(2451);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
// EXTERNAL MODULE: ./components/HeroFrom.jsx + 1 modules
var HeroFrom = __webpack_require__(4571);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1440);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
;// CONCATENATED MODULE: ./components/AirlineTable.jsx
/* __next_internal_client_entry_do_not_use__ default auto */ 






const AirlineTable = async ()=>{
    const data = await AirlineFetch();
    // const airlineFlights = await AirlineFlight(params)
    const baseURL = "https://rdpmarketplace.com/backend/";
    const imageLoader = ({ src, width, quality })=>{
        return `https://rdpmarketplace.com/backend/${src}`;
    };
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("section", {
                className: "w-100 p-[80px] bg-[url(https://cdn.flight-status.info/images/banner.webp)]",
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "container",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                            className: "text-black text-[32px]",
                            children: "Flight status tracker - Check the current status of your flight"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                            className: "text-black text-[14px] mt-6",
                            children: "Check flight status of more than 500 airlines all in one place. We bring you the best platform to check Flight status. The tracker helps you in collecting the most information about your flights. With the real-time GPS tracking, we make you aware of all information related to a flight such as live flight status, arrival and departure, delay or cancel time of the flights."
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "bg-white w-100 shadow-sm px-5 py-10 mt-4",
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "flex space-x-5 items-center",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                            className: "text-[14px] mb-0",
                                            children: "Search by:"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                            className: "block cursor-pointer text-[14px] rounded-full bg-[#0078D2] p-2 text-white",
                                            children: "Airlines and airports status"
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx(HeroFrom["default"], {})
                            ]
                        })
                    ]
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "container pt-20",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                        className: "text-left w-100 mb-10 text-[#0078d2] text-[24px]",
                        children: "List Airlines for checking Flight Status"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "relative overflow-x-auto w-100 mx-auto",
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("table", {
                            className: "w-full text-sm text-left text-gray-500 dark:text-gray-400",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("thead", {
                                    className: "text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400",
                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("tr", {
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("th", {
                                                scope: "col",
                                                className: "px-6 py-3",
                                                children: "#"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("th", {
                                                scope: "col",
                                                className: "px-6 py-3",
                                                children: "Airline"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("th", {
                                                scope: "col",
                                                className: "px-6 py-3",
                                                children: "Iata"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("th", {
                                                scope: "col",
                                                className: "px-6 py-3",
                                                children: "ICao"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("th", {
                                                scope: "col",
                                                className: "px-6 py-3"
                                            })
                                        ]
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("tbody", {
                                    children: data?.data?.slice(0, 32).map((i)=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)("tr", {
                                            className: "bg-white border-b dark:bg-gray-800 dark:border-gray-700",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("td", {
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                                        loader: imageLoader,
                                                        src: i.airline_logo != null ? `${i.airline_logo}` : "uploads/admin/airline/flight-img.jpg",
                                                        alt: "flight image",
                                                        width: 240,
                                                        height: 80,
                                                        className: "h-[80px]"
                                                    })
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("td", {
                                                    className: "px-6 py-4 font-bold text-[#0078d2] w-[40%]",
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                        className: "no-underline",
                                                        href: `/airline/${i.airline_slug}`,
                                                        children: i.airline_name
                                                    })
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("td", {
                                                    className: "px-6 py-4 font-bold text-gray-800",
                                                    children: i.airline_iata_code
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("td", {
                                                    className: "px-6 py-4 font-bold text-gray-800",
                                                    children: i.airline_icao_code
                                                }),
                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("td", {
                                                    className: "px-6 py-4 font-regular text-gray-800",
                                                    children: [
                                                        i.airline_date_founded,
                                                        " Flight Founds"
                                                    ]
                                                })
                                            ]
                                        }, i.id))
                                })
                            ]
                        })
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const components_AirlineTable = (AirlineTable);


/***/ }),

/***/ 4571:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ components_HeroFrom)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(6786);
// EXTERNAL MODULE: external "next/dist/compiled/react"
var react_ = __webpack_require__(8038);
// EXTERNAL MODULE: ./node_modules/axios/lib/axios.js + 46 modules
var axios = __webpack_require__(3258);
;// CONCATENATED MODULE: ./fetch/AirlineNameFetch.jsx

async function AirlineNameFetch(name) {
    const airline = await axios/* default */.Z.get(`http://localhost/flight/airline/${name}`);
    //console.log(airline.data)
    return airline.data.data;
}

;// CONCATENATED MODULE: ./components/HeroFrom.jsx
/* __next_internal_client_entry_do_not_use__ default auto */ 


const airlineNameContext = /*#__PURE__*/ (/* unused pure expression or super */ null && (createContext()));
const HeroFrom = ()=>{
    const [name, setName] = (0,react_.useState)();
    const onSubmitMy = (e)=>{
        e.preventDefault();
    };
    const handleChange = async (e)=>{
        setName(e.target.value);
        const res = await AirlineNameFetch(name);
    //console.log(res)
    };
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("form", {
        className: "mt-5",
        onSubmit: onSubmitMy,
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("label", {
                className: "text-[14px] w-100",
                children: "Name*"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("input", {
                onChange: handleChange,
                className: "mt-2 border w-[300px] h-[40px] text-[14px] indent-5",
                type: "text",
                placeholder: "Enter Name to Search"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("button", {
                className: "block mt-3 text-white bg-[#0078D2] py-2 px-10 ms-auto",
                children: "Search"
            })
        ]
    });
};
/* harmony default export */ const components_HeroFrom = (HeroFrom);


/***/ }),

/***/ 3403:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ZP: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* unused harmony exports __esModule, $$typeof */
/* harmony import */ var next_dist_build_webpack_loaders_next_flight_loader_module_proxy__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1363);

const proxy = (0,next_dist_build_webpack_loaders_next_flight_loader_module_proxy__WEBPACK_IMPORTED_MODULE_0__.createProxy)(String.raw`D:\flight_project\components\AirlineTable.jsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule, $$typeof } = proxy;
const __default__ = proxy.default;


/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (__default__);

/***/ })

};
;